This is a one paged restuarnt website template which has short codes 
